//based on

// Learning Processing
// Daniel Shiffman
// modified Feb 5, 2026


// Rollovers
//finish the rollover

void setup() {
  size(200,200);
  
  
}

void draw() {
  background(255);
  stroke(0);
  line(width/2,0,width/2,height);
  line(0,height/2,width,height/2);
  
  // Fill a black color
  noStroke();
  fill(0);

  // Depending on the mouse location, a different rectangle is displayed.    
  if (mouseX < width/2) {
  if (mouseY < height/2) {
    rect(0, 0, width/2, height/2);
  }
 }
}
//Complete the sketch so that the quadrant containing the mouse 
//is highlighted.

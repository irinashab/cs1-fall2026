//teleportation of a ball
//IS
//09/23/23


int x=0,y=50,xSpeed=2;

void setup() {
  size(800,200);
  
  
}

void draw() {
  background(255);
  circle(x,y,30);
  x=x+xSpeed;
  
  if(x>width){
    x=0;
   // xSpeed=-xSpeed;
    
  }
}

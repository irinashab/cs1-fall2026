// ********************************************
// CS1 - Lesson 2 Example 4
// Irina Shablinsky
// August 2026
// ********************************************
//beginShape() different modes
// Uncomment one section at a time to see how different modes work.
void setup(){
size(500,500);
background(255);//white background
noFill();
}
void draw(){
  //default mode
beginShape();
vertex(120, 80);
vertex(340, 80);
vertex(340, 300);
vertex(120, 300);
endShape(CLOSE);

//mode POINTS

//stroke(255,0,0);//red stroke
//strokeWeight(10);//thick stroke
//beginShape(POINTS);
//vertex(120, 80);
//vertex(340, 80);
//vertex(340, 300);
//vertex(120, 300);
//endShape();

//mode LINES
//stroke(0,255,0);//green stroke
//beginShape(LINES);
//vertex(120, 80);
//vertex(340, 80);
//vertex(340, 300);
//vertex(120, 300);
//endShape();

//mode TRIANGLES
//fill(224,217,89);//yellowish fill
//beginShape(TRIANGLES);
//vertex(270, 80);
//vertex(280, 300);
//vertex(320, 80);
//vertex(120, 300);
//vertex(160, 120);
//vertex(200, 300);
//endShape();

//mode TRIANGLE_STRIP
//fill(200,76,197);//purple fill
//beginShape(TRIANGLE_STRIP);
//vertex(120, 300);
//vertex(160, 80);
//vertex(200, 300);
//vertex(240, 80);
//vertex(280, 300);
//vertex(320, 80);
//vertex(360, 300);
//endShape();
}

// ********************************************
// CS1 - Lesson 2 Example 1
// Irina Shablinsky
// August 2026
// ********************************************
// The sketch prints the position of the mouse
// to the console. This can help you when planning a drawing on the canvas.



void setup(){
  size(500,500);
  background(255);
}

void draw(){
  // Print the current mouse position.
  println(mouseX, mouseY);
  
}

// ********************************************
// CS1 - Lesson 2 Example 6
// Irina Shablinsky
// August 2026
// ********************************************
//Inspired by Malevich's Suprematist composition


void setup(){
  size(705, 700);
  noStroke();
}

void draw(){
  background(234,234,216);
  //big yellow square at the bottom
  fill(232,172,10);
  rect(335,455,200,200);
  //yellow rectangle
  fill(216,165,24);
  beginShape();
  vertex(245,95);
  vertex(285,145);
  vertex(208,213);
  vertex(165,165);
  endShape(CLOSE);
  //black skinny rectangle
  fill(0);
  beginShape();
  vertex(314,146);
  vertex(333,161);
  vertex(125,340);
  vertex(108,324);
  endShape(CLOSE);
  //black trapezoid
  fill(0);
  beginShape();
  vertex(242,267);
  vertex(274,315);
  vertex(204,364);
  vertex(171,311);
  endShape(CLOSE);
  //red rectangle
  fill(232,78,7);
  beginShape();
  vertex(400,250);
  vertex(444,314);
  vertex(215,463);
  vertex(173,402);
  endShape(CLOSE);
  //black rectangle next to the red one
  fill(0);
  beginShape();
  vertex(510,270);
  vertex(550,334);
  vertex(422,416);
  vertex(384,354);
  endShape(CLOSE);
}

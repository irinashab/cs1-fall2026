// ********************************************
// CS1 - Lesson 2 Example 3
// Irina Shablinsky
// August 2026
// ********************************************
//beginShape() TRIANGLES mode

void setup() {
  size(400, 400);
  background(255);

stroke(0);
strokeWeight(2);
  beginShape(TRIANGLES);
  vertex(100, 100);// Vertices 1–3 form the first triangle.
  vertex(150, 200);
  vertex(200, 100);
  vertex(250, 200);// Vertices 4–6 form the second triangle.
  vertex(300, 100);
  vertex(200, 300);
  endShape();
  // Why do you see only one triangle?
   //Uncomment the code  below to see which vertices form triangles
//  strokeWeight(10);
//  stroke(250,0,0);
//  point(100, 100);
//  point(150, 200);
//  point(200, 100);
//point(250,200);
//point(300,100);
//point(200,300);
}

// ********************************************
// CS1 - Lesson 2 Example 0
// Irina Shablinsky
// August 2026
// ********************************************
//Your new friends setup() and draw() are shown
// setup() runs once.
// draw() runs repeatedly.
void setup(){
  size(300,200);
  background(0);
  frameRate(12);
}

void draw() {
  
  println("I am printing this message 12 times a second!");
}

// ********************************************
// CS1 - Lesson 2 Example 2
// Irina Shablinsky
// August 2026
// ********************************************
//Example of a simple shape created using its vertices

void setup() {
  size(400, 400);
  background(255);
  textSize(16);
 fill(0, 255, 0); // Green text
  text("vertex 1", 110,110);
  text("vertex 2", 145,210);
  text("vertex 3", 210,110);
  text("vertex 4", 310,50);
  noFill();
}
void draw(){
beginShape();
  vertex(100, 100);
  vertex(150, 200);
  vertex(200, 100);
  vertex(300,50);
endShape(CLOSE); // Use CLOSE to connect vertex 4 to vertex 1
  
}

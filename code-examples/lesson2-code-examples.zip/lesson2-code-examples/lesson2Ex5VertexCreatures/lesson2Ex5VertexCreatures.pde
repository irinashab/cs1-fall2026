// ********************************************
// CS1 - Lesson 2 Example 5
// Irina Shablinsky
// August 2026
// ********************************************
//creatures

void setup(){
  size(500,150);
}
  void draw(){
    background(255);
    fill(255);
// Left creature
  beginShape();
  vertex(50, 120);
  vertex(100, 90);
  vertex(110, 60);
  vertex(80, 20);
  vertex(210, 60);
  vertex(160, 80);
  vertex(200, 90);
  vertex(140, 100);
  vertex(130, 120);
  endShape(CLOSE);
  

 // Right creature
  
  beginShape();
  vertex(370, 120);
  vertex(360, 90);
  vertex(290, 80);
  vertex(340, 70);
  vertex(280, 50);
  vertex(420, 10);
  vertex(390, 50);
  vertex(410, 90);
  vertex(460, 120);
  endShape(CLOSE);
  
  fill(0);
   ellipse(155, 60, 8, 8);//left creature's eye
   ellipse(340, 60, 8, 8);//right creature's eye
  }

// ********************************************
// CS1 - Lesson 1 Example 1
// Irina Shablinsky
// July 2026
// ********************************************

// Draw three bounding boxes using different rect modes
// Draw an ellipse inside each box.
// Notice that each ellipse uses the same parameters as its box.

  size(400, 400);
  smooth();
  background(255);
  // bounding boxes
  strokeWeight(2);
  noFill();//all rectangles have no fill
  rect(100, 120, 130, 100);//point (100,120) is the upper left corner of the rect
  rectMode(CENTER);
  rect(100, 120, 130, 100);
  rectMode(CORNERS);
  rect(230, 220, 360, 320);
  
  //draw ellipses in each box
  //pay attention to parameters of the ellipses,
  //they are the same as parameters of the boxes
  strokeWeight(5);
  fill(221,22,220,125);
  ellipse(100, 120, 130, 100);//purple ellipse
  ellipseMode(CORNER);
  fill(208,222,22,125);//yellow ellipse
  ellipse(100, 120, 130, 100);
  fill(20,222,53,125);
  ellipseMode(CORNERS);
  ellipse(230, 220, 360, 320);//green ellipse

  

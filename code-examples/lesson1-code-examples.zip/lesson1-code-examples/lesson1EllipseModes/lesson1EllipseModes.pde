// ********************************************
// CS1 - Lesson 1 Example 2
// Irina Shablinsky
// July 2026
// ********************************************

//Sketch demonstrates different ellipse modes

 size(400, 400);
background(255);
strokeWeight(10);
fill(127,127);//semitransparent gray fill color
//by default ellipseMode(CENTER) is applied
ellipse(200, 200, 170, 170);//black circle, the center is at the center of the canvas,
// 170 is a diameter
ellipseMode(RADIUS);
stroke(255,255,9);
ellipse(200, 200, 170, 170);//yellow circle, now radius is 170
ellipseMode(CORNER);
stroke(0,255,13);
strokeWeight(3);
ellipse(200, 200, 170, 170);// green circle, now (200, 200)  are the coordinates
//of the bounding box

noFill();
rect(200,200, 170, 170);

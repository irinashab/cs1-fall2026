// ********************************************
// CS1 - Lesson 1 Example 3
// Irina Shablinsky
// July 2026
// ********************************************


//Sketch demonstrates different rectangle modes

  size(400, 400);
  background(255);
  strokeWeight(10);
  //by default rectMode(CORNER)is applied
  fill(38,227,25);
  rect(100, 120, 130, 100);//green rect
  rectMode(CENTER);
  fill(242,224,22,150);
  rect(100, 120, 130, 100);//yellow rectangle
  rectMode(CORNERS);
  fill(173, 172,167);
  rect(230, 220, 360, 320);//grey rectangle

// ********************************************
// CS1 - Lesson 1 Example 0
// Irina Shablinsky
// July 2026
// ********************************************


//simple shapes examples



  size(600, 400);      // You can change the canvas size as you like
 


  background(245);     // Light gray background to make colors pop

  
  stroke(0, 90);  //Sets the color used to draw lines and 
  //borders around shapes to slightly transparent black
  strokeWeight(2);              
  line(300, 0, 300, 400);//vertical line through the center of the canvas

  
  line(0, 200, 600,200);//horizontal line through the center of the canvas

 
  

 // Circle with diameter 200, centered at the upper-left corner of the canvas
  
  noStroke();//Disables drawing the stroke (outline).
  fill(255, 120, 0, 170);      // Orange with transparency
  ellipse(0, 0, 200, 200);

  // More shapes: 
  // Translucent overlapping rectangles
  noStroke();
  fill(50, 180, 255, 120);
  rect(350, 40, 180, 110);//upper-left corner is in the point (350,40), rectangle width is 180.
  //what is the rectangle height?

  fill(180, 50, 255, 120);
  rect(300, 90, 150, 110);

  // A triangle with a semi-transparent fill
  fill(60, 200, 120, 150);
  triangle(120, 330, 220, 260, 280, 360); //all three corners must be specified

  // A quad (4-sided polygon)
  fill(255, 60, 100, 130);
  quad(430, 260, 550, 240, 540, 330, 420, 340);

  
  

  // Optional: a tiny crosshair at the center so you can  see the midpoint
  stroke(0);//black
  strokeWeight(3);
  line(width/2 - 6, height/2, width/2 + 6, height/2);//width and height stand for the size of the canvas
  line(width/2, height/2 - 6, width/2, height/2 + 6);//in our case width is 600, height is 400

  

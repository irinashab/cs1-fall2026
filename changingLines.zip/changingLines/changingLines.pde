//IS
//Last modified 8/22/2024

//experimenting with lines and the position of the mouse

void setup() {
  size(480, 270);//the size of the canvas
 background(255);// Try moving background() to draw() and see the difference!
 
}


void draw() {
  
 
  
  
  strokeWeight(5);//the width of your line
stroke(237,123,42);//the color of your line

  // mouseX is a keyword that the sketch replaces with the horizontal position of the mouse.
  // mouseY is a keyword that the sketch replaces with the vertical position of the mouse.
 line(mouseX, mouseY, pmouseX, pmouseY);

}
